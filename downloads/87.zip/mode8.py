# pip install pyzmq cbor keyboard
from zmqRemoteApi_IPv6 import RemoteAPIClient
import keyboard

client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')



sim.startSimulation()
print('Simulation started')

def setBubbleRobVelocity(leftWheelVelocity1, rightWheelVelocity1, leftWheelVelocity2, rightWheelVelocity2):
    leftMotor1 = sim.getObject('/81')
    rightMotor1 = sim.getObject('/82')
    leftMotor2 = sim.getObject('/83')
    rightMotor2 = sim.getObject('/84')
    sim.setJointTargetVelocity(leftMotor1, leftWheelVelocity1)
    sim.setJointTargetVelocity(rightMotor1, rightWheelVelocity1)
    sim.setJointTargetVelocity(leftMotor2, leftWheelVelocity2)
    sim.setJointTargetVelocity(rightMotor2, rightWheelVelocity2)
   

'''
# Example usage 1:
setBubbleRobVelocity(1.0, 1.0)
time.sleep(2)
setBubbleRobVelocity(0.0, 0.0)
'''
# use keyborad to move BubbleRob

while True:
    if keyboard.is_pressed('up'):
        setBubbleRobVelocity(15.0, 15.0, 15.0, 15.0)
    elif keyboard.is_pressed('down'):
        setBubbleRobVelocity(-15.0, -15.0, -15.0, -15.0)
    elif keyboard.is_pressed('left'):
        setBubbleRobVelocity(-5.0, 5.0, -5.0, 5.0)
    elif keyboard.is_pressed('right'):
        setBubbleRobVelocity(5.0, -5.0, 5.0, -5.0)
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
    else:
        setBubbleRobVelocity(0.0, 0.0, 0.0, 0.0)




