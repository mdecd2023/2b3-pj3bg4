from zmqRemoteApi_IPv6 import RemoteAPIClient
import time
import math
import keyboard

client = RemoteAPIClient('localhost', 23000)
sim = client.getObject('sim')
sensor = sim.getObject('/Floor/G/sensor2')
sensor1 = sim.getObject('/Floor/R/sensor1')

ball = sim.getObject('/ball')
joint1 = sim.getObject('/joint1')
joint2 = sim.getObject('/joint2')
joint3 = sim.getObject('/joint3')
joint4 = sim.getObject('/joint4')
counter1 = 0
counter = 0

result = sim.readProximitySensor(sensor)
result1 = sim.readProximitySensor(sensor1)
print("team green", counter1)
print("team red", counter)

last_executed_multiple = 0  # 初始化上次執行的倍數
t = 600
s = [
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 0, 1, 0],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 0, 1, 0],
    [1, 1, 0, 1, 0, 1, 1],
    [1, 1, 0, 1, 1, 1, 1],
    [1, 0, 1, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 1, 1]
]


def score(x, y):
    for i in range(10):
        if x == i:
            for j in range(7):
                part = sim.getObject('/scoreboard/' + y + str(j))
                if s[i][j] == 1:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [1, 1, 1])
                else:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [0, 0, 0])


def sysCall_init():
    global t

    t = 600

    score(1, 'a')
    score(0, 'b')
    score(0, 'c')
    score(0, 'd')


def sysCall_actuation():
    global t

    minutes = math.floor(t / 60)
    seconds = t % 60

    t1 = math.floor(minutes / 10)
    t2 = minutes % 10
    t3 = math.floor(seconds / 10)
    t4 = seconds % 10

    score(t1, 'a')
    score(t2, 'b')
    score(t3, 'c')
    score(t4, 'd')

    t -= 1

    if t < 0:
        sim.pauseSimulation()

    p = sim.getSimulationState()
    if p == 22:
        score(0, 'a')
        score(0, 'b')
        score(0, 'c')
        score(0, 'd')


sysCall_init()

while t >= 0:
    result = sim.readProximitySensor(sensor)
    _, detection_state, _, _, _ = result
    if detection_state:
        print("GOAL！")
        counter1 += 1
        print("team green", counter1)
        sim.setObjectPosition(ball, -1, [0, 0, 0.5])
        target_angle = math.radians(36)
        current_angle = sim.getJointPosition(joint1)
        new_angle = current_angle + target_angle
        sim.setJointTargetPosition(joint1, new_angle)

        if counter1 > 1 and counter1 % 10 == 0 and counter1 != last_executed_multiple + 1:
            target_angle = math.radians(36)
            current_angle = sim.getJointPosition(joint2)
            new_angle = current_angle + target_angle
            sim.setJointTargetPosition(joint2, new_angle)
            last_executed_multiple = counter1

    result1 = sim.readProximitySensor(sensor1)
    _, detection_state1, _, _, _ = result1
    if detection_state1:
        print("GOAL！")
        counter += 1
        print("team red", counter)
        sim.setObjectPosition(ball, -1, [0, 0, 0.5])
        target_angle = math.radians(36)
        current_angle = sim.getJointPosition(joint3)
        new_angle = current_angle + target_angle
        sim.setJointTargetPosition(joint3, new_angle)

        if counter > 1 and counter % 10 == 0 and counter != last_executed_multiple + 1:
            target_angle = math.radians(36)
            current_angle = sim.getJointPosition(joint4)
            new_angle = current_angle + target_angle
            sim.setJointTargetPosition(joint4, new_angle)

    time.sleep(0.005)
    sysCall_actuation()
while True:
    time.sleep(1)
    sysCall_actuation()
    if keyboard.is_pressed('q'):
        break

print("Simulation Stop")
print("time stop")
