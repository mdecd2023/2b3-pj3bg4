from zmqRemoteApi_IPv6 import RemoteAPIClient
import time
import math
import keyboard

client = RemoteAPIClient('localhost', 23000)
sim = client.getObject('sim')
sensor = sim.getObject('/Floor/G/sensor2')
sensor1 = sim.getObject('/Floor/R/sensor1')
ib = sim.getObject('/IB')
ib2 = sim.getObject('/IB/IB')

red1 = sim.getObject('/r1/r1')
red2 = sim.getObject('/r2/r2')
red3 = sim.getObject('/r3/r3')
red4 = sim.getObject('/r4/r4')

green1 = sim.getObject('/g1/g1')
green2 = sim.getObject('/g2/g2')
green3 = sim.getObject('/g3/g3')
green4 = sim.getObject('/g4/g4')

last_sensor_touch = None
print(last_sensor_touch)

ball = sim.getObject('/ball')
joint1 = sim.getObject('/joint1')
joint2 = sim.getObject('/joint2')
joint3 = sim.getObject('/joint3')
joint4 = sim.getObject('/joint4')
counter1 = 0
counter = 0

result = sim.readProximitySensor(sensor)
result1 = sim.readProximitySensor(sensor1)
print("team green", counter1)
print("team red", counter)
sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 0, 1])
sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 0, 1])

last_executed_multiple = 0
t = 600
s = [
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 0, 1, 0],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 0, 1, 0],
    [1, 1, 0, 1, 0, 1, 1],
    [1, 1, 0, 1, 1, 1, 1],
    [1, 0, 1, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 1, 1]
]


def score(x, y):
    for i in range(10):
        if x == i:
            for j in range(7):
                part = sim.getObject('/scoreboard/' + y + str(j))
                if s[i][j] == 1:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [1, 1, 1])
                else:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [0, 0, 0])


def sysCall_actuation():
    global t
    minutes = math.floor(t / 60)
    seconds = t % 60
    t1 = math.floor(minutes / 10)
    t2 = minutes % 10
    t3 = math.floor(seconds / 10)
    t4 = seconds % 10
    score(t1, 'a')
    score(t2, 'b')
    score(t3, 'c')
    score(t4, 'd')
    t -= 1
    if t < 0:
        sim.pauseSimulation()
    p = sim.getSimulationState()
    if p == 22:
        score(0, 'a')
        score(0, 'b')
        score(0, 'c')
        score(0, 'd')


while True:
    resultred1 = sim.readProximitySensor(red1)
    resultred2 = sim.readProximitySensor(red2)
    resultred3 = sim.readProximitySensor(red3)
    resultred4 = sim.readProximitySensor(red4)
    resultgreen1 = sim.readProximitySensor(green1)
    resultgreen2 = sim.readProximitySensor(green2)
    resultgreen3 = sim.readProximitySensor(green3)
    resultgreen4 = sim.readProximitySensor(green4)
    _, detection_statered1, _, _, _ = resultred1
    _, detection_statered2, _, _, _ = resultred2
    _, detection_statered3, _, _, _ = resultred3
    _, detection_statered4, _, _, _ = resultred4
    _, detection_stategreen1, _, _, _ = resultgreen1
    _, detection_stategreen2, _, _, _ = resultgreen2
    _, detection_stategreen3, _, _, _ = resultgreen3
    _, detection_stategreen4, _, _, _ = resultgreen4
    if detection_statered1:
        last_sensor_touch = 'red1'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
    elif detection_statered2:
        last_sensor_touch = 'red2'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
    elif detection_statered3:
        last_sensor_touch = 'red3'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
    elif detection_statered4:
        last_sensor_touch = 'red4'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [1, 0, 0])
    elif detection_stategreen1:
        last_sensor_touch = 'green1'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
    elif detection_stategreen2:
        last_sensor_touch = 'green2'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
    elif detection_stategreen3:
        last_sensor_touch = 'green3'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
    elif detection_stategreen4:
        last_sensor_touch = 'green4'
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 1, 0])
    else:
        last_sensor_touch = None
        sim.setShapeColor(ib, None, sim.colorcomponent_ambient_diffuse, [0, 0, 1])
        sim.setShapeColor(ib2, None, sim.colorcomponent_ambient_diffuse, [0, 0, 1])

    if last_sensor_touch is not None and last_sensor_touch.startswith('green'):
        counter1 += 1
    elif last_sensor_touch is not None and last_sensor_touch.startswith('red'):
        counter += 1

    if keyboard.is_pressed('p'):
        sim.pauseSimulation()

    if keyboard.is_pressed('r'):
        sim.resumeSimulation()

    if keyboard.is_pressed('s'):
        sim.stopSimulation()

    if keyboard.is_pressed('q'):
        sim.startSimulation()

    if keyboard.is_pressed('w'):
        sim.resetDynamicObject(ball)

    if keyboard.is_pressed('up'):
        joint1.setJointPosition(0.1)

    if keyboard.is_pressed('down'):
        joint1.setJointPosition(-0.1)

    if keyboard.is_pressed('left'):
        joint2.setJointPosition(0.1)

    if keyboard.is_pressed('right'):
        joint2.setJointPosition(-0.1)

    if keyboard.is_pressed('a'):
        joint3.setJointPosition(0.1)

    if keyboard.is_pressed('s'):
        joint3.setJointPosition(-0.1)

    if keyboard.is_pressed('z'):
        joint4.setJointPosition(0.1)

    if keyboard.is_pressed('x'):
        joint4.setJointPosition(-0.1)

    if keyboard.is_pressed('m'):
        current_time = time.time()
        if current_time - last_executed_multiple > 1:
            last_executed_multiple = current_time
            t += 60
