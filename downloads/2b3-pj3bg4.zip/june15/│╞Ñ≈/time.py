from zmqRemoteApi_IPv6 import RemoteAPIClient
import time
import math

client = RemoteAPIClient('localhost', 23000)
sim = client.getObject('sim')
print('time go')
t = 600

s = [
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 0, 1, 0],
    [1, 0, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 0, 1, 1],
    [0, 1, 1, 1, 0, 1, 0],
    [1, 1, 0, 1, 0, 1, 1],
    [1, 1, 0, 1, 1, 1, 1],
    [1, 0, 1, 0, 0, 1, 0],
    [1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 1, 1]
]

def score(x, y):
    for i in range(10):
        if x == i:
            for j in range(7):
                part = sim.getObject('/scoreboard/' + y + str(j))
                if s[i][j] == 1:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [1, 1, 1])
                else:
                    sim.setShapeColor(part, None, sim.colorcomponent_ambient_diffuse, [0, 0, 0])

def sysCall_init():
    global t

    t = 600

    score(1, 'a')
    score(0, 'b')
    score(0, 'c')
    score(0, 'd')

def sysCall_actuation():
    global t

    minutes = math.floor(t / 60)
    seconds = t % 60

    t1 = math.floor(minutes / 10)
    t2 = minutes % 10
    t3 = math.floor(seconds / 10)
    t4 = seconds % 10

    score(t1, 'a')
    score(t2, 'b')
    score(t3, 'c')
    score(t4, 'd')

    t -= 1

    if t < 0:
        sim.pauseSimulation()

    p = sim.getSimulationState()
    if p == 22:
        score(0, 'a')
        score(0, 'b')
        score(0, 'c')
        score(0, 'd')

sysCall_init()
while True:
    time.sleep(1)
    sysCall_actuation()